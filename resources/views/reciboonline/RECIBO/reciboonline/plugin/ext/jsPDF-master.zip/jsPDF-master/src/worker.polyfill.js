/**
 * polyfill to make jspdf work in a webworker
 * @type {{}}
 */

window = {};